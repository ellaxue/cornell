package ChooseSelectionImp;

/**
 * Scan options
 * @author Chengcheng Ji (cj368), Pei Xu (px29) and Ella Xue (ex32)
 *
 */
public enum SELECT_METHOD {
	FULL_SCAN, INDEX_SCAN;
}
